for (let i=0;i<=10;i++){
    document.write("The Number Is" +i+ "</br><hr/>");
}

let i=0;
while(i<=10){
    document.write("Number is"+i+"</br>");
    i++;
}

let j=0;
do{
    document.write("Number is"+j+"</br><hr/>");
    j++;
}
while (j<=10);


const Human = {FirstName:"Abhishek", LastName:"Pujara", age:25+ "<hr/><hr/>"};
for (let H in Human) {
    document.write("<br/>"+H);
  }
document.write("<hr/><hr/>");
for (let H in Human) {
  document.write("<br/>"+Human[H]);
}


const cities = ["New York", "Tokiyo", "Delhi"+"<hr/><hr/>"];
for (C of cities) {
  document.write("<br/>"+C);
}