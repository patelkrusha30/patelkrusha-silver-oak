// $(document).ready(function(){
			
//     alert("Welcome To homepage");
//     $("#show").attr("disabled",true);

//     $("#hide").click(function(){
//         if(confirm("Are You sure..?")){
//             $("#MyDiv").hide(1000);
//             $("#show").attr("disabled",false);
//             $(this).attr("disabled",true);
//         }	
//     });
        
//     $("#show").click(function(){
//         if(confirm("Are You sure..?")){
//             $("#MyDiv").show(1000);
//             $("#hide").attr("disabled",false);
//             $(this).attr("disabled",true);
//         }
//     });

//     $("#Toggle").click(function(){
//         if(confirm("Are you sure..??"))
//         {
//             $("#MyDiv").toggle(1000);
//             ($(this).text()=="hide")
//             ?($(this).text("show"),$("#hide").attr("disabled",true),$("#show").attr("disabled",false))
//             :($(this).text("hide"),$("#hide").attr("disabled",false),$("#show").attr("disabled",true));
//         }
//     });

//     $("#Plus").click(function(){
//         var MDhW=parseInt($("#MyDiv").css("height"));
//         if(MDhW<=400){
//             MDhW+=30;
//             $("#MyDiv").css("height",MDhW);
//             $("#MyDiv").css("width",MDhW);
//         }
//         else{
//             alert("More 500px is not possible.");
//         }
//     });

//     $("#Minus").click(function(){
//         var MDhW=parseInt($("#MyDiv").css("height"));
//         if(MDhW>=50)
//         {
//             MDhW-=10;
//             $("#MyDiv").css("height",MDhW);
//             $("#MyDiv").css("width",MDhW);
//         }
//         else{
//             alert("Less 50px is not possible.");
//         }
//     });

// });



			
$(document).ready(function(){

    alert("Welcome To Homepage");
    $("#BtnShow").attr("disabled",true);

    $("#BtnHide").click(function(){
        if(confirm("Are You Sure..?")){
            $("#MyDiv").hide(1000);
            $("#BtnShow").attr("disabled",false);
            $(this).attr("disabled",true);
        }	
    });
        
    $("#BtnShow").click(function(){
        if(confirm("Are You Sure..?")){
            $("#MyDiv").show(1000);
            $("#BtnHide").attr("disabled",false);
            $(this).attr("disabled",true);
        }
    });

    $("#BtnToggle").click(function(){
        if(confirm("Are you sure..??"))
        {
            $("#MyDiv").toggle(1000);
            ($(this).text()=="Hide")
            ?($(this).text("Show"),$("#BtnHide").attr("disabled",true),$("#BtnShow").attr("disabled",false))
            :($(this).text("Hide"),$("#BtnHide").attr("disabled",false),$("#BtnShow").attr("disabled",true));
        }
    });

    $("#BtnPlus").click(function(){
        var MDHW=parseInt($("#MyDiv").css("height"));
        if(MDHW<=400){
            MDHW+=30;
            $("#MyDiv").css("height",MDHW);
            $("#MyDiv").css("width",MDHW);
        }
        else{
            alert("More 500px is not possible.");
        }
    });

    $("#BtnMinus").click(function(){
        var MDHW=parseInt($("#MyDiv").css("height"));
        if(MDHW>=50)
        {
            MDHW-=10;
            $("#MyDiv").css("height",MDHW);
            $("#MyDiv").css("width",MDHW);
        }
        else{
            alert("Less 50px is not possible.");
        }
    });

});

