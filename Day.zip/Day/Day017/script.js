var $FNameLNameRegEx = /^([a-zA-Z]{2,20})$/;
			var $FullNameRegEx = /^([a-zA-Z ]{2,40})$/;
			var $BankAccountNameRegEx = /^([a-zA-Z ]{2,60})$/;
			var $PasswordRegEx = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,12}$/;

			var $EmailIdRegEx = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,8}\b$/i;
			var $ConNoRegEx = /^([0-9]{10})$/;
			var $AgeRegEx = /^([0-9]{1,2})$/;
			var $AadhaarNoRegEx = /^([0-9]{12})$/;
			var $GSTNoRegEx=/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
			var $IndianDrivingLicenseNoRegEx = /^([A-Z]{2,3}[-/0-9]{8,13})$/;
			var $IndianVehicleRegNoRegEx = /^([A-Z]{2}[0-9]{1,2}[A-Z]{1,3}[0-9]{1,4})$/;
			var $PincodeRegEx = /^[1-9][0-9]{5,6}$/;
			var $PANNoRegEx = /^[A-Z]{3}[ABCFGHLJPT][A-Z][0-9]{4}[A-Z]$/;
			var $IFSCCodeRegEx = /^[A-Za-z]{4}0[A-Z0-9a-z]{6}$/;
			var $BankAccountNoRegEx = /^([0-9]{9,18})$/;
			var $PostTitleRegex =/^(.{30,300})$/;
			var $PostDescRegex = /^(.{100,3000})$/;
			var $LatitudeLongitude=/^(-?(?:1[0-7]|[1-9])?\d(?:\.\d{1,8})?|180(?:\.0{1,8})?)$/;
			
			$(document).ready(function(){
				var TxtNameFlag=false,TxtContactNoFlag=false,TxtEmailIdFlag=false,TxtContactMsgFlag=false;
				
				$("#TxtName").blur(function(){
					$("#TxtNameValidation").empty();
					if($(this).val()=="" || $(this).val()==null)
					{
						$("#TxtNameValidation").html("(*) Firstname required..!!");
					}
					else{
						if(!$(this).val().match($FNameLNameRegEx))
						{
							$("#TxtNameValidation").html("(*) Invalid firstname..!!");
						}
					}
				});

				$("#TxtName").keypress(function(e){
					var flag=false;
					$("#TxtNameValidation").empty();
					((e.which>=65 && e.which<=90) || (e.which>=97 && e.which<=122))
					?flag=true
					:(flag=false,$("#TxtNameValidation").html("Invalid keypress..!!"))
					return flag;
				});	


				$("#TxtContactNo").blur(function(){
					$("#TxtContactNoValidation").empty();
					if($(this).val()=="" || $(this).val()==null)
					{
						$("#TxtContactNoValidation").html("(*) Contact no. required..!!");
					}
					else{
						if(!$(this).val().match($ConNoRegEx))
						{
							$("#TxtContactNoValidation").html("(*) Invalid contact no..!!");
						}
					}
				});

				$("#TxtContactNo").keypress(function(e){
					var flag=false;
					$("#TxtContactNoValidation").empty();
					(e.which>=48 && e.which<=57)
					?flag=true
					:(flag=false,$("#TxtContactNoValidation").html("Invalid keypress..!!"))
					return flag;
				});

				$("#TxtEmailId").blur(function(){
					$("#TxtEmailIdValidation").empty();
					if($(this).val()=="" || $(this).val()==null)
					{
						$("#TxtEmailIdValidation").html("(*) Email id required..!!");
					}
					else{
						if(!$(this).val().match($EmailIdRegEx))
						{
							$("#TxtEmailIdValidation").html("(*) Invalid email id..!!");
						}
					}
				});

				$("#TxtContactMsg").blur(function(){
					$("#TxtContactMsgValidation").empty();
					if($(this).val()=="" || $(this).val()==null)
					{
						$("#TxtContactMsgValidation").html("(*) Contact no. required..!!");
					}
					else{
						if($(this).val().length>20)
						{
							$("#TxtContactMsgValidation").html("(*) Invalid contact message..!!");
						}
					}
				});

				$("#BtnSubmit").click(function(){
					$("#TxtNameValidation").empty();
					if($("#TxtName").val()=="" || $("#TxtName").val()==null)
					{
						$("#TxtNameValidation").html("(*) Firstname required..!!");
						TxtNameFlag=false;
					}
					else{
						if(!$("#TxtName").val().match($FNameLNameRegEx))
						{
							$("#TxtNameValidation").html("(*) Invalid firstname..!!");
							TxtNameFlag=false;
						}
						else{
							TxtNameFlag=true;
						}
					}
					$("#TxtContactNoValidation").empty();
					if($("#TxtContactNo").val()=="" || $("#TxtContactNo").val()==null)
					{
						$("#TxtContactNoValidation").html("(*) Contact no. required..!!");
						TxtContactNoFlag=false;
					}
					else{
						if(!$("#TxtContactNo").val().match($ConNoRegEx))
						{
							$("#TxtContactNoValidation").html("(*) Invalid contact no..!!");
							TxtContactNoFlag=false;
						}
						else{
							TxtContactNoFlag=true;
						}
					}
					$("#TxtEmailIdValidation").empty();
					if($("#TxtEmailId").val()=="" || $("#TxtEmailId").val()==null)
					{
						$("#TxtEmailIdValidation").html("(*) Email id required..!!");
						TxtEmailIdFlag=false;
					}
					else{
						if(!$("#TxtEmailId").val().match($EmailIdRegEx))
						{
							$("#TxtEmailIdValidation").html("(*) Invalid email id..!!");
							TxtEmailIdFlag=false;
						}
						else{
							TxtEmailIdFlag=true;
						}
					}
					$("#TxtContactMsgValidation").empty();
					if($("#TxtContactMsg").val()=="" || $("#TxtContactMsg").val()==null)
					{
						$("#TxtContactMsgValidation").html("(*) Contact no. required..!!");
						TxtContactMsgFlag=false;
					}
					else{
						if($("#TxtContactMsg").val().length>3000)
						{
							$("#TxtContactMsgValidation").html("(*) Invalid contact message..!!");
							TxtContactMsgFlag=false;
						}
						else{
							TxtContactMsgFlag=true;
						}
					}
					if(TxtNameFlag==true && TxtContactNoFlag==true && TxtEmailIdFlag==true && TxtContactMsgFlag==true)
					{
						$("input,textarea").val("");
						alert("Form submitted successfully..!!");
					}
					else{
						alert("Invalid input..!!");
					}
				});

			});


